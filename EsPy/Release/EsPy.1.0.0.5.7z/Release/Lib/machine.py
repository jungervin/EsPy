﻿class Pin:
    #init', 'value', 'low', 'high', 'irq', 'IN', 'OUT', 'OPEN_DRAIN', 'PULL_UP', 'IRQ_RISING', 'IRQ_FALLING'

    def __init__(self, pin_id):
        pass

    def value(value):
        pass

    def low():
        pass

    def high():
        pass

    def irq():
        pass

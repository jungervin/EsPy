﻿class Pin():
    #init', 'value', 'low', 'high', 'irq', 'IN', 'OUT', 'OPEN_DRAIN', 'PULL_UP', 'IRQ_RISING', 'IRQ_FALLING'

    def __init__(self, pin_id):
        pass

    def value(self, value):
        pass

    def low(self):
        pass

    def high(self):
        pass

    def irq(self):
        pass
